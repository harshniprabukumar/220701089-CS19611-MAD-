package com.example.project;

public class Speech {
    public String text;
    public  int i;
    public Speech(String text,int i) {
        this.text = text;
        this.i = i;
    }
}
